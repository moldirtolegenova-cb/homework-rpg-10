package com.narxoz.rpg;

import com.narxoz.rpg.combatant.Hero;
import com.narxoz.rpg.council.*;
import com.narxoz.rpg.guild.*;
import com.narxoz.rpg.quest.*;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        System.out.println("=== Homework 10 Demo: Iterator + Mediator ===");

        // 1. Setup Quests
        QuestLog log = new QuestLog();
        log.add(new Quest("Kill Rats", QuestPriority.LOW, 10, false));
        log.add(new Quest("Slay Dragon", QuestPriority.URGENT, 5000, true));
        log.add(new Quest("Clear Ruin", QuestPriority.HIGH, 500, false));

        // 2. Setup Mediator and Members
        GuildHall hall = new GuildHall();
        new Captain("Valerius", hall);
        new Scout("Elara", hall);
        
        // OPEN/CLOSED PROOF: Adding Loremaster without changing GuildHall logic
        new Loremaster("Thalric", hall); 

        // 3. Demonstrate Iterator Extension (Reward Sorting)
        System.out.println("\n--- Quests Sorted by Reward (Extension) ---");
        QuestIterator rewardIt = new RewardSortedQuestIterator(log);
        while (rewardIt.hasNext()) {
            System.out.println(rewardIt.next());
        }

        // 4. Run the Engine
        List<Hero> party = List.of(new Hero("Grog", 100, 20, 10));
        CouncilEngine engine = new CouncilEngine();
        
        // This will now include Loremaster in the message routing automatically
        CouncilRunResult result = engine.runCouncil(party, log, hall);

        System.out.println("\n--- Final Report ---");
        System.out.println(result);
    }
}